/*CREATE TABLE customer AS SELECT customerid, invoiceno, invoicedate, stockcode, description, quantity, unitprice, totalsale, country FROM retail;*/
 
/*SELECT * FROM customer WHERE COALESCE(customerid, '') = ''
AND COALESCE(description, '') = '';*/

/*UPDATE customer SET	customerid = NULL, description = NULL 
WHERE customerid = '' OR description = '';*/

/*SELECT * FROM customer WHERE TRIM(totalsale) = '$-';*/

/*DELETE FROM customer
WHERE customerid = '' OR customerid IS NULL
AND description = '' OR description IS NULL;*/

/*ALTER TABLE customer
ALTER COLUMN invoicedate TYPE DATE
USING to_date(invoicedate,  'YYYY-MM-DD');*/

/*ALTER TABLE customer
ALTER COLUMN totalsale TYPE MONEY
USING CAST(totalsale AS MONEY);*/

/*ALTER TABLE customer
ALTER COLUMN unitprice TYPE MONEY
USING CAST(unitprice AS MONEY);*/

/*ALTER TABLE customer ADD COLUMN tran_id SERIAL PRIMARY KEY;*/

/*SELECT DISTINCT customerid FROM customer;*/

/*ALTER TABLE customer
DROP COLUMN invoiceno, 
DROP COLUMN invoicedate, 
DROP COLUMN stockcode, 
DROP COLUMN description,
DROP COLUMN quantity, 
DROP COLUMN unitprice, 
DROP COLUMN totalsale;*/

/*SELECT DISTINCT country FROM customer;*/

/*SELECT country, STRING_AGG(distinct customerid, ',') AS customer_ids
FROM customer
GROUP BY country;*/

/*SELECT customerid, country, COUNT(DISTINCT invoiceno) as no_orders,
  SUM(quantity * unitprice) as total_spend
FROM retail
GROUP BY customerid, country
HAVING 
 SUM(quantity * unitprice) > 1000::money
ORDER BY total_spend DESC;*/