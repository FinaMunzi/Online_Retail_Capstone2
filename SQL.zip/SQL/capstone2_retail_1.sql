/*SELECT * FROM retail;*/

/*ALTER TABLE retail
ALTER COLUMN unitprice TYPE MONEY
USING CAST(unitprice AS MONEY);*/

/*ALTER TABLE retail
ALTER COLUMN totalsale TYPE MONEY
USING CAST(totalsale AS MONEY);*/

/*SELECT stockcode, description, SUM(quantity) as totalquantity,
  SUM(quantity * unitprice) as totalrevenue FROM retail
GROUP BY stockcode, description
ORDER BY totalquantity DESC, totalrevenue DESC
LIMIT 10;*/

/*SELECT DATE_TRUNC('month', invoicedate::timestamp) AS Month, country, 
 SUM(quantity * unitprice) as monthly_rev FROM retail
GROUP BY month, country
ORDER BY month ASC, monthly_rev DESC;*/

/*SELECT customerid, description, COUNT(*) AS num_purchases
FROM retail
WHERE customerid != '' AND description != ''
GROUP BY customerid, description
ORDER BY customerid ASC, num_purchases DESC;*/
  
/*SELECT description, SUM(quantity) AS total_units_sold,
SUM(quantity * unitprice) AS total_revenue,
SUM(quantity * totalsale - (quantity * unitprice)) AS total_profit
FROM retail
WHERE description != ''
GROUP BY description
ORDER BY total_units_sold DESC;*/

--most profitable product

/*SELECT description, SUM(quantity) as total_quantity,
 SUM(quantity * unitprice) as total_revenue,
 AVG(unitprice::numeric) as avg_unitprice,
 SUM(quantity * ( totalsale - unitprice )) as total_profit
FROM retail
WHERE description <> '' AND unitprice::numeric > 0 AND quantity > 0
GROUP BY description
ORDER BY total_quantity DESC, total_profit DESC;*/

/*SELECT DATE_TRUNC('month', invoicedate::timestamp)::DATE AS monthly_perform, 
COUNT(*) AS count
FROM retail
GROUP BY DATE_TRUNC('month', invoicedate::timestamp)::DATE
ORDER BY DATE_TRUNC('month', invoicedate::timestamp)::DATE;*/

-- SELECT DISTINCT description FROM retail;

/*SELECT category, COUNT(*) AS no_items from 
( SELECT CASE 
WHEN description LIKE '%T%-%LIGHT%' THEN 'candles'
WHEN description LIKE '%LANTERN%' THEN 'candles'
WHEN description LIKE '%CANDLE%' THEN 'candles'
WHEN description LIKE '%BOTTLE%' THEN 'kitchenware'
WHEN description LIKE '%PLAYHOUSE%' THEN 'toys'
WHEN description LIKE '%DOLL%' THEN 'toys'
WHEN description LIKE '%CUP %' THEN 'kitchenware'
WHEN description LIKE '%HANGER%' THEN 'household'
WHEN description LIKE '%BLOCK%' THEN 'toys'
WHEN description LIKE '%COAT RACK%' THEN 'household'
WHEN description LIKE '%GAME%' THEN 'toys'
WHEN description LIKE '%TEA%' THEN 'kitchenware'
WHEN description LIKE '%LUNCH%' THEN 'kitchenware'
WHEN description LIKE '%SNACK%' THEN 'kitchenware'
WHEN description LIKE '%LIGHT%' THEN 'lighting'
WHEN description LIKE '%JIGSAW%' THEN 'toys'
WHEN description LIKE '%CHRISTMAS%' THEN 'seasonal'
WHEN description LIKE '%WARMER%' THEN 'household'
WHEN description LIKE '%DRAWER%' THEN 'household'
WHEN description LIKE '%CUTLERY%' THEN 'kitchenware'
WHEN description LIKE '%ORNAMENT%' THEN 'decorations'
WHEN description LIKE '%EARRINGS%' THEN 'accessories'
WHEN description LIKE '%TAPE%' THEN 'stationary'
WHEN description LIKE '%PAN%' THEN 'kitchenware'
WHEN description LIKE '%EASTER%' THEN 'seasonal'
WHEN description LIKE '%BABUSHKA%' THEN 'lighting'
WHEN description LIKE '%RING%' THEN 'accessories'
WHEN description LIKE '%NECKLACE%' THEN 'accessories'
WHEN description LIKE '%HAMPER%' THEN 'promotion'
WHEN description LIKE '% POT% 'THEN 'kitchenware'
WHEN description LIKE '%MUG %' THEN 'kitchenware'
WHEN description LIKE '%CHILD%' THEN 'toys'
WHEN description LIKE '%COSMETIC%' THEN 'womans'
WHEN description LIKE '%POPCORN% 'THEN 'kitchenware'
WHEN description LIKE '% STICKER %' THEN 'stationary'
WHEN description LIKE '% PENCILS %' THEN 'stationary'
WHEN description LIKE '% PEN %' THEN 'stationary'
WHEN description LIKE '% DRAWING %' THEN 'stationary'
WHEN description LIKE '% NAPKINS %' THEN 'kitchenware'
WHEN description LIKE '%EGG%' THEN 'kitchenware'
WHEN description LIKE '% CARD %' THEN 'stationary'
WHEN description LIKE '%JUG%' THEN 'kitchenware'
WHEN description LIKE '%ENVELOPE%' THEN 'stationary'
WHEN description LIKE '%BIRTHDAY%' THEN 'party'
WHEN description LIKE '%CAKE%' THEN 'kitchenware'
WHEN description LIKE '%SEW%' THEN 'stationary'
WHEN description LIKE '%COLORING% 'THEN 'stationary'
WHEN description LIKE '%DISH%' THEN 'kitchenware'
WHEN description LIKE '%JAR%' THEN 'kitchenware'
WHEN description LIKE '%RIBBONS%' THEN 'stationary'
WHEN description LIKE '%CURTAIN%' THEN 'household'
WHEN description LIKE '%DECORATION%' THEN 'decorations'
WHEN description LIKE '%DESK%' THEN 'household'
WHEN description LIKE '%CHAIR%' THEN 'household'
WHEN description LIKE '%TOTE%' THEN 'stationary'
WHEN description LIKE '%NAPKINS%' THEN 'party'
WHEN description LIKE '%BEAD%' THEN 'accessories'
WHEN description LIKE '%MAGNET%' THEN 'stationary'
WHEN description LIKE '%CUSHION%' THEN 'household'
WHEN description LIKE '%OVEN%' THEN 'kitchenware'
WHEN description LIKE '%JAM%' THEN 'kitchenware'
WHEN description LIKE '%BOOK%' THEN 'stationary'
WHEN description LIKE '%BOX%' THEN 'box'
WHEN description LIKE '%DRESS%' THEN 'womans'
WHEN description LIKE '%TRAY%' THEN 'kitchenware'
WHEN description LIKE '%BURNER%' THEN 'candles'
WHEN description LIKE '%HAMMOCK%' THEN 'outdoor'
WHEN description LIKE '%BREAD%' THEN 'kitchenware'
WHEN description LIKE '%CRAWLIES%' THEN 'seasonal'
WHEN description LIKE '%CLOCK%' THEN 'stationary'
WHEN description LIKE '%TISSUES%' THEN 'household'
WHEN description LIKE '%PAPER%' THEN 'stationary'

ELSE 'others'
END AS category
FROM retail)
AS catogorised_products
GROUP BY category;*/