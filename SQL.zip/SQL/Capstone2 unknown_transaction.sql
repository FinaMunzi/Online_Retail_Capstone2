
/*CREATE TABLE unknown_transaction(
invoiceno TEXT, invoicedate DATE, stockcode TEXT, quantity INT, totalsale TEXT, country TEXT);*/

/*INSERT INTO unknown_transaction SELECT invoiceno, CAST(invoicedate AS DATE), stockcode, quantity, totalsale, country FROM customer
WHERE COALESCE(customerid, '') = ''
AND COALESCE(description, '') = '';*/

/*SELECT * FROM unknown_transaction;*/

/*ALTER TABLE unknown_transaction ADD COLUMN id SERIAL PRIMARY KEY;*/

/*ALTER TABLE unknown_transaction
ALTER COLUMN totalsale TYPE MONEY
USING CAST(totalsale AS MONEY);*/

/*SELECT SUM(totalsale) FROM unknown_transaction;*/

/*SELECT DISTINCT u.stockcode, COUNT(u.quantity), r.description FROM unknown_transaction u
INNER JOIN retail r
ON u.stockcode = r.stockcode
GROUP BY u.stockcode, r.description
ORDER BY 1, 2 asc;*/

/*SELECT COUNT(*) as num_transactions, country
FROM unknown_transaction
GROUP BY country;*/

